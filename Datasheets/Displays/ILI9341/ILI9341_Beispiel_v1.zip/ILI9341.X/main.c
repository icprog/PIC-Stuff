/*******************************************************************************
 * File:        main.c
 * Project:     ILI9341
 * Author:      Nicolas Meyert�ns
 * Version:     siehe main.h
 * Web:         http://pic-projekte.de
 ******************************************************************************/

#include <xc.h>
#include "main.h"
#include "peri.h"
#include "lcd.h"

#pragma config FOSC = INTIO67   // Internal oscillator block
#pragma config PWRTEN = ON      // Power up timer enabled
#pragma config BOREN = OFF      // Brown-out Reset disabled
#pragma config WDTEN = OFF      // Watch dog timer is always disabled
#pragma config MCLRE = INTMCLR  // MCLR disabled
#pragma config LVP = OFF        // Single-Supply ICSP disabled

/*******************************************************************************
 * Diverse Einstellungen zum PIC (IO, Takt, ...)
 */

void initPIC(void)
{
    LATC = 0x00;
    LATE = 0x00;
    
    TRISA = 0x00;
    TRISB = 0x00;
    TRISC = 0x00;
    TRISD = 0x00;
    TRISE = 0x00;
            
    ANSELA = 0x00;
    ANSELB = 0x00;
    ANSELC = 0x00;
    ANSELD = 0x00;
    ANSELE = 0x00;
    
    OSCTUNEbits.PLLEN = 1;      // enable PLL (4 times)
    OSCCON2bits.MFIOSEL = 0;    // 111: 16 MHz <
    OSCCONbits.IRCF2 = 1;       // 110:  8 MHz
    OSCCONbits.IRCF1 = 1;       // 101:  4 MHz
    OSCCONbits.IRCF0 = 1;       // 100:  2 MHz
}

/*******************************************************************************
 * Durchf�hren s�mtlicher Initialisierungen beim Bootvorgang
 */

void initAll (void)
{
    initPIC();  // IO, Takt, ...
    initSPI();  // SPI Bus
    lcd_init(); // TFT Initialisierung
}

/*******************************************************************************
 * 1ms Delay-Function
 */

void msDelay (uint8_t ms)
{
    uint8_t k;
    
    for(k=0; k<ms; k++)
    {
        __delay_ms(1);
    }
}

/*******************************************************************************
 * Main Routine
 */

void main (void)
{
    /*Alle Initialisierungen durchf�hren*/
    initAll();

    lcd_draw_string(80,160,"XC8-Bibliothek - ILI9341",BLUE,global_bg_color);
    lcd_draw_circle(68,168,8,WHITE);
    lcd_draw_line(82,155,250,155,YELLOW);
    lcd_draw_string(110,120,"PIC-Projekte.de",RED,global_bg_color);
    
    /*Endlosschleife*/
    while(1)
    {

    }
}

/* *****************************************************************************
 * File:        peri.h
 * Project:     ILI9341
 * Author:      Nicolas Meyert�ns
 * Version:     siehe setup.h
 * Web:         www.PIC-Projekte.de
 * ****************************************************************************/

#ifndef PERI_H
#define	PERI_H

#include <xc.h>
#include <stdint.h>
#include <stdint.h>

/*Prototypen*/
void initSPI(void);
uint8_t sendSPI (uint8_t byte);

#endif	/* PERI_H */

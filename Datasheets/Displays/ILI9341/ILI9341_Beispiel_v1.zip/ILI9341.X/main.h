/*******************************************************************************
 * File:        main.h
 * Project:     ILI9341
 * Author:      Nicolas Meyert�ns
 * Version:     siehe Defines
 * Web:         http://pic-projekte.de
 ******************************************************************************/

#ifndef MAIN_H
#define	MAIN_H

#include <stdint.h>

#define _XTAL_FREQ  64000000 // Clock frequency in Hz

void msDelay(uint8_t ms);

#endif	/* MAIN_H */

/*******************************************************************************
 * File:        peri.c
 * Project:     ILI9341
 * Author:      Nicolas Meyert�ns
 * Version:     siehe main.h
 * Web:         http://pic-projekte.de
 ******************************************************************************/

#include "peri.h"

/*******************************************************************************
 * Einstellen des SPI-Moduls
 * Clock = Fosc / (4*(SSP1ADD+1)) = 64 MHz / (4*(1+1)) = 64 MHz / 8 = 8 MHz
 */

void initSPI(void)
{
    SSP1ADD = 1;
    SSP1CON1 = 0b00001010;      // Clock = Fosc /(4*(SSPxADD+1)) und CKP = 0 (CLK idle is low)
    SSP1STATbits.CKE = 1;       // Transmit occurs from idle to active (CLK))
    SSP1CON1bits.SSPEN = 1;     // SPI Modul nur einschalten wenn n�tig
}

/*******************************************************************************
 * �bertragung eines Bytes auf dem SPI Bus
 *
 * byte: Das zu �bertragende Byte
 * R�ckgabewert: Das empfangene Byte
 */

uint8_t sendSPI (uint8_t byte)
{
    SSPBUF = byte;
    while(!SSP1STATbits.BF);
    
    return SSPBUF;
}

/*******************************************************************************
 * File:        lcd.c
 * Project:     ILI9341
 * Author:      Nicolas Meyert�ns
 * Version:     siehe main.h
 * Web:         http://pic-projekte.de
 ******************************************************************************/

#include <stdlib.h>
#include "lcd.h"
#include "peri.h"
#include "main.h"
#include "font.h"

/*******************************************************************************
 * Globale Variablen
 */

uint16_t global_bg_color = BLACK;

/*******************************************************************************
 * Initialisierung des Displays mit einer frei waehlbaren Hintergrundfarbe
 */

void lcd_init (void)
{    
    lcd_send(LCD_REG,  0xCB);
    lcd_send(LCD_DATA, 0x39);
    lcd_send(LCD_DATA, 0x2C);
    lcd_send(LCD_DATA, 0x00);
    lcd_send(LCD_DATA, 0x34);
    lcd_send(LCD_DATA, 0x02);

    lcd_send(LCD_REG,  0xCF);
    lcd_send(LCD_DATA, 0x00);
    lcd_send(LCD_DATA, 0XC1);
    lcd_send(LCD_DATA, 0X30);

    lcd_send(LCD_REG,  0xE8);
    lcd_send(LCD_DATA, 0x85);
    lcd_send(LCD_DATA, 0x00);
    lcd_send(LCD_DATA, 0x78);

    lcd_send(LCD_REG,  0xEA);
    lcd_send(LCD_DATA, 0x00);
    lcd_send(LCD_DATA, 0x00);

    lcd_send(LCD_REG,  0xED);
    lcd_send(LCD_DATA, 0x64);
    lcd_send(LCD_DATA, 0x03);
    lcd_send(LCD_DATA, 0X12);
    lcd_send(LCD_DATA, 0X81);

    lcd_send(LCD_REG,  0xF7);
    lcd_send(LCD_DATA, 0x20);

    lcd_send(LCD_REG,  0xC0); // Power control
    lcd_send(LCD_DATA, 0x23); // VRH[5:0]

    lcd_send(LCD_REG,  0xC1); // Power control
    lcd_send(LCD_DATA, 0x10); // SAP[2:0];BT[3:0]

    lcd_send(LCD_REG,  0xC5); // VCM control
    lcd_send(LCD_DATA, 0x3e);
    lcd_send(LCD_DATA, 0x28);

    lcd_send(LCD_REG,  0xC7); // VCM control2
    lcd_send(LCD_DATA, 0x86);

    lcd_send(LCD_REG,  0x36); // Memory Access Control
    lcd_send(LCD_DATA, 0x88); // C8

    lcd_send(LCD_REG,  0x3A);
    lcd_send(LCD_DATA, 0x55);

    lcd_send(LCD_REG,  0xB1);
    lcd_send(LCD_DATA, 0x00);
    lcd_send(LCD_DATA, 0x18);

    lcd_send(LCD_REG,  0xB6); // Display Function Control
    lcd_send(LCD_DATA, 0x08);
    lcd_send(LCD_DATA, 0x82);
    lcd_send(LCD_DATA, 0x27);

    lcd_send(LCD_REG,  0xF2); // 3Gamma Function Disable
    lcd_send(LCD_DATA, 0x00);

    lcd_send(LCD_REG,  0x26); // Gamma curve selected
    lcd_send(LCD_DATA, 0x01);

    lcd_send(LCD_REG,  0xE0); // Set Gamma
    lcd_send(LCD_DATA, 0x0F);
    lcd_send(LCD_DATA, 0x31);
    lcd_send(LCD_DATA, 0x2B);
    lcd_send(LCD_DATA, 0x0C);
    lcd_send(LCD_DATA, 0x0E);
    lcd_send(LCD_DATA, 0x08);
    lcd_send(LCD_DATA, 0x4E);
    lcd_send(LCD_DATA, 0xF1);
    lcd_send(LCD_DATA, 0x37);
    lcd_send(LCD_DATA, 0x07);
    lcd_send(LCD_DATA, 0x10);
    lcd_send(LCD_DATA, 0x03);
    lcd_send(LCD_DATA, 0x0E);
    lcd_send(LCD_DATA, 0x09);
    lcd_send(LCD_DATA, 0x00);

    lcd_send(LCD_REG,  0xE1); // Set Gamma
    lcd_send(LCD_DATA, 0x00);
    lcd_send(LCD_DATA, 0x0E);
    lcd_send(LCD_DATA, 0x14);
    lcd_send(LCD_DATA, 0x03);
    lcd_send(LCD_DATA, 0x11);
    lcd_send(LCD_DATA, 0x07);
    lcd_send(LCD_DATA, 0x31);
    lcd_send(LCD_DATA, 0xC1);
    lcd_send(LCD_DATA, 0x48);
    lcd_send(LCD_DATA, 0x08);
    lcd_send(LCD_DATA, 0x0F);
    lcd_send(LCD_DATA, 0x0C);
    lcd_send(LCD_DATA, 0x31);
    lcd_send(LCD_DATA, 0x36);
    lcd_send(LCD_DATA, 0x0F);

    lcd_send(LCD_REG,  0x11); // Sleep out
    msDelay(120);
    lcd_send(LCD_REG, 0x2c);  
    lcd_fill(global_bg_color);
    
    lcd_send(LCD_REG, 0x29); // Display on 
    lcd_send(LCD_REG, 0x2c);
}

/*******************************************************************************
 * Daten werden via SPI-Bus an den Display-Controller gesendet
 */

void lcd_send(bool dc, uint8_t value)
{   
    /* register or data */
    LCD_DC = dc;

    /* transmit via SPI */
    LCD_CS = 0;
    sendSPI(value);
    LCD_CS = 1;
}

/*******************************************************************************
 * Platzieren des Cursors an Punkt (x,y)
 */

uint8_t lcd_set_cursor(uint16_t x, uint16_t y)
{
    if( lcd_set_cursor_x(x) || lcd_set_cursor_y(y) )
    {
        return EXIT_FAILURE;
    }
	
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * Teilplatzierung des Cursors an (x,_)
 */

uint8_t lcd_set_cursor_x(uint16_t x)
{
    if( x >= LCD_WIDTH )
    {
        return EXIT_FAILURE;
    }
    
    lcd_send(LCD_REG,  0x2B);
    lcd_send(LCD_DATA, x >> 8);
    lcd_send(LCD_DATA, x & 0xFF);
    lcd_send(LCD_REG, 0x2c);
    
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * Teilplatzierung des Cursors an (_,y)
 */

uint8_t lcd_set_cursor_y(uint16_t y)
{
    if( y >= LCD_HEIGHT ) 
    {
        return EXIT_FAILURE;
    }
    
    lcd_send(LCD_REG,  0x2A);
    lcd_send(LCD_DATA, y >> 8);
    lcd_send(LCD_DATA, y & 0xFF);
    lcd_send(LCD_REG, 0x2c);
    
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * Zeichnen eines Pixels an die aktuelle Cursorposition
 */

uint8_t lcd_draw_pixel(uint16_t color)
{
    lcd_send(LCD_DATA, color >> 8);
    lcd_send(LCD_DATA, color & 0xFF);
    
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * Fuellen des gesamten Displays mit einer frei waehlbaren Farbe
 */

void lcd_fill(uint16_t bg_color)
{   
    uint16_t width = LCD_WIDTH, height = LCD_HEIGHT;
    
    if( lcd_set_cursor(0,0) )
    {
        return;
    }
    
    while(height--)
    {
        while(width--)
        {
            lcd_draw_pixel(bg_color);
        }
        width = LCD_WIDTH;
    }
}

/*******************************************************************************
 * Zeichnen einer Linie von (x0,y0) zu (x1,y1)
 */

void lcd_draw_line(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color)
{
    int16_t dx = x1 - x0, sx = x0 < x1 ? 1 : -1;
    int16_t dy = y1 - y0, sy = y0 < y1 ? 1 : -1; 
    int16_t err, e2;
    
    if(x0 > x1)
    {
        dx = -dx;
    }
    
    if(y1 > y0)
    {
        dy = -dy;
    }
    
    err = dx + dy;
    
    while(true)
    {
        lcd_draw_pixel_at( x0, y0, color);

        if ( (x0 == x1) && (y0 == y1) )
        {
            break;
        }

        e2 = (err << 1);

        if(e2 >= dy)
        {
            err += dy; 
            x0 += sx;
        }

        if(e2 <= dx)
        {
            err += dx;
            y0 += sy;
        }
    }
}

/*******************************************************************************
 * Zeichnen eines Pixels an dem Punkt (x,y) mit Farbe <color>
 */

void lcd_draw_pixel_at(uint16_t x, uint16_t y, uint16_t color)
{
    if( !lcd_set_cursor(x,y) )
    {
        lcd_draw_pixel(color);
    }
}

/*******************************************************************************
 * Zeichnen eines ausgefuellten Rechteckes mit den Punkten (x0,y0) und (x1,y1)
 */

void lcd_fill_rect(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color)
{
    uint16_t y_start = y0;

    if( (y0 >= LCD_HEIGHT) || (x0 >= LCD_WIDTH) ) 
    {
        return;
    }
    
    if( x1 >= LCD_WIDTH )
    {
        x1 = LCD_WIDTH;
    }
    
    if( y1 >= LCD_HEIGHT )
    {
        y1 = LCD_HEIGHT;
    }
	
    while( x0 <= x1 )
    {
        lcd_set_cursor(x0++, y0);

        while( y0++ <= y1 )
        {
            lcd_draw_pixel(color);
        }
        y0 = y_start;
    }
} 

/*******************************************************************************
 * Zeichnen eines Kreises mit dem Zentrum (xm,ym) und dem Radius (r)
 */

void lcd_draw_circle(uint16_t xm, uint16_t ym, uint16_t r, uint16_t color)
{
    int16_t f = 1 - r, ddF_x = 1, ddF_y = 0 - (2 * r);
    int16_t x = 0, y = r;

    lcd_draw_pixel_at(xm, ym + r, color);
    lcd_draw_pixel_at(xm, ym - r, color);
    lcd_draw_pixel_at(xm + r, ym, color);
    lcd_draw_pixel_at(xm - r, ym, color);

    while(x < y)
    {
        if(f >= 0)
        {
          y--;
          ddF_y += 2;
          f += ddF_y;
        }
        
        x++;
        ddF_x += 2;
        f += ddF_x;
        
        lcd_draw_pixel_at(xm + x, ym + y, color);
        lcd_draw_pixel_at(xm - x, ym + y, color);
        lcd_draw_pixel_at(xm + x, ym - y, color);
        lcd_draw_pixel_at(xm - x, ym - y, color);
        lcd_draw_pixel_at(xm + y, ym + x, color);
        lcd_draw_pixel_at(xm - y, ym + x, color);
        lcd_draw_pixel_at(xm + y, ym - x, color);
        lcd_draw_pixel_at(xm - y, ym - x, color);
    }
}

/*******************************************************************************
 * Zeichnen eines gefuellten Kreises mit dem Zentrum (xm,ym) und dem Radius (r)
 */

void lcd_draw_filled_circle (uint16_t xm, uint16_t ym, uint8_t r, uint16_t color)
{
    int16_t f = 1 - r, ddF_x = 1, ddF_y = 0 - (2*r), x = 0, y = r;

    lcd_draw_line(xm-r, ym, xm+r, ym, color);
    
    while(x < y)
    {
        if(f >= 0)
        {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        
        x++;
        ddF_x += 2;
        f += ddF_x;
        
        lcd_draw_line(xm - x, ym + y, xm + x, ym + y, color);
        lcd_draw_line(xm - x, ym - y, xm + x, ym - y, color);
        lcd_draw_line(xm - y, ym + x, xm + y, ym + x, color);
        lcd_draw_line(xm - y, ym - x, xm + y, ym - x, color);
    }
}

/*******************************************************************************
 * Zeichnen eines Zeichens an Position (x,y) - Diese Funktion kann nur indirekt
 * mit Hilfe der Funktion lcd_draw_string aufgerufen werden, da diese den 
 * entsprechenden Index fuer den font-Vector berechnet!
 */

void lcd_draw_char (uint16_t x, uint16_t y, uint16_t fIndex, uint16_t fg_color, uint16_t bg_color)
{
    uint8_t j, k, i;
    
    for(j=0; j < font[fIndex]; j++) // variable character width
    {
        lcd_set_cursor(x + font[fIndex] - j, y); // print from right to left
        
        for(k=0; k<FONT_HEIGHT; k++) // _ bytes per character (height)
        {
            for(i=0; i<8; i++)
            {
                if( font[ (fIndex + ((font[fIndex]) << 1)) - (j<<1) - k ] & (0x80 >> i) )
                {
                    lcd_draw_pixel(fg_color);
                }
                else
                {
                    lcd_draw_pixel(bg_color);
                }
            }
        }
    }
}

/*******************************************************************************
 * Zeichnen einer Zeichenkette ab Position (x,y)
 */

void lcd_draw_string (uint16_t x, uint16_t y, const char *pS, uint16_t fg_color, uint16_t bg_color)
{    
    uint16_t lIndex, k;
    
    while(*pS)
    {
        /* index the width information of character <c> */
        lIndex = 0;
        for(k=0; k<(*pS - ' '); k++)
        {
            lIndex += ((font[lIndex]) << 1) + 1;
        }
        
        /* draw character */
        lcd_draw_char(x, y, lIndex, fg_color, bg_color);
        
        /* move the cursor forward for the next character */
        x += font[lIndex];
        
        /* next charachter */
        pS++;
    }
}

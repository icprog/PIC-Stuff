/*
 * File:   main.c
 * Author: exploreembedded
 *
 * Created on May 21, 2016, 12:11 PM
 */


#include <xc.h>

void main(void) {
    return;
}
